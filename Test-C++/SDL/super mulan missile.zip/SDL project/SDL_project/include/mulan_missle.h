#ifndef MULAN_MISSLE_H
#define MULAN_MISSLE_H
#define MLDEBUG 1
#include "ball.h"
class mulan_missle:protected ball
{
    public:
        static unsigned int mis_amount;
        mulan_missle();
        mulan_missle(double x,double y);
        virtual ~mulan_missle();
        void missle_initialize(double p_x,double p_y);
        void move(double V);
        bool is_out_of_boarder(int x,int y);
        void draw(SDL_Renderer* pRenderer);
        void super_missile_enable(){twins[0].enable_super=twins[1].enable_super=1;}
    protected:

    private:
    pos mass_heart;
    pos vec;//sin and cos
    ball* twins;//the missiles
    pos tw_v[2];//the missiles' velocity
    unsigned int routine;//the routine of mass heart's change velocity
    static const double dR;//the amount of velocity change
    void single_twin_update(double V,int num);
};

#endif // MULAN_MISSLE_H

#ifndef BALL_H
#define BALL_H
#include "SDL.h"
#include "SDL2_gfxPrimitives.h"
class ball
{
    public:
        static int ball_num;
        struct rgba
        {
            char r,g,b,a;
        };
        struct pos
        {
            double x,y;
        };
        ball();
        virtual ~ball();
        void draw_ball(SDL_Renderer* pRenderer);
        void reset();
        void super();
        void change_color();
        void pos_reset(int red_x,int red_y);
        void change_pos(int p_x,int p_y);
        void change_pos_by_V(double dx,double dy);
        double* get_pos();
        rgba color;
        bool enable_super;
    protected:
        double x,y;
        unsigned int ban_ji;

        bool rad_c_vec;
};
#endif // BALL_H

#include <iostream>
#include "game.h"
using namespace std;
int main(int argc, char *argv[])
{
    game GAME;
    GAME.game_event();

    return 0;
}

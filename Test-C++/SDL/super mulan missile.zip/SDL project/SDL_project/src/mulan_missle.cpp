#include "mulan_missle.h"
#include <math.h>
#include <iostream>

#if MLDEBUG==1
#define DEBUG(str) str
#else
#define DEBUG(str) ;
#endif

typedef mulan_missle mlm;
typedef ball::pos pos;
unsigned int mlm::mis_amount=0;
const double mlm::dR=1.0;
const double G=0.000007;

pos G_v_change_amount(pos big,pos lit,double V)
{
    double range=sqrt(pow(big.x-lit.x,2)+pow(big.y-lit.y,2));
    double strength=G*(range*range)*V;
    double costh=(big.x-lit.x)/range;
    double sinth=(big.y-lit.y)/range;
    pos v_change;
    v_change.x=strength*costh;
    v_change.y=strength*sinth;
    return v_change;
}
void just_for_debug(std::string in)
{
    std::cout<<in;
    //char waste;
    //std::cin>>waste;
}
double pi_transform(double v)
{
    return v*3.1415926/180;
}
mulan_missle::mulan_missle(double x/*the start point*/,
                           double y):routine (5.5)
{
    DEBUG(just_for_debug("mulan_missle::mulan_missle\n");)
    mass_heart.x=x;
    mass_heart.y=y;
    vec.x=0;
    vec.y=0;
    twins=new ball[2];
    twins[0].change_pos(x,y);
    twins[1].change_pos(x,y);
    twins[0].change_color();
    twins[1].change_color();
    mis_amount++;
}
mulan_missle::mulan_missle()
{
    twins=new ball[2];
    mis_amount++;
}
mulan_missle::~mulan_missle()
{
    DEBUG(just_for_debug("mulan_missle::~mulan_missle\n");)
    delete [] twins;
    mis_amount--;
}
void mulan_missle::missle_initialize(double p_x/*the way where it goes.*/,
                                     double p_y)
{
    DEBUG(just_for_debug("mulan_missle::missle_initialize\n");)
    //initialize all the velocity of missile
    double vx=p_x-mass_heart.x,vy=p_y-mass_heart.y;
    if(vx==0)
    {
        vec.y=((vy>0)? 1:-1);
    }
    else if(vy==0)
    {
        vec.x=((vx>0)? 1:-1);
    }
    else
    {
        double p=sqrt(vx*vx+vy*vy);
        vec.x=vx/p;//cos
        vec.y=vy/p;//sin
    }
    tw_v[0].x=-vec.y/1.5;
    tw_v[0].y=vec.x/1.5;
    tw_v[1].x=vec.y/1.5;
    tw_v[1].y=-vec.x/1.5;
}
void mlm::single_twin_update(double V,int num)
{
    //get position
    pos t_p;//twins' position
    double *pb;//buffer
    pb=twins[num].get_pos();
    t_p.x=pb[0];
    t_p.y=pb[1];
    //gravity calculation (about velocity change)
    t_p=G_v_change_amount(mass_heart,t_p,V);
    //##notice##
    //At here "t_p" were the change amount of velocity
    //And NO lONGER stands for position
    tw_v[num].x+=t_p.x;
    tw_v[num].y+=t_p.y;
    twins[num].change_pos_by_V(tw_v[num].x*V,tw_v[num].y*V);
}
void mulan_missle::move(double V)
{
    DEBUG(just_for_debug("mulan_missle::move\n");)
    //mass heart update
    double curV=V*sin(pi_transform(routine))*1.5;
    if(sin(pi_transform(routine))<0)
    {
        std::cout<<"ERROR"<<'\n';
        std::cout<<routine<<" sin:"<<sin(pi_transform(routine));
        SDL_Delay(10000);
    }
    mass_heart.x+=(vec.x*curV);
    mass_heart.y+=(vec.y*curV);
    routine+=(dR);
    routine%=180;
    single_twin_update(V,0);
    single_twin_update(V,1);
}
void mlm::draw(SDL_Renderer* pRenderer)
{
    DEBUG(just_for_debug("mlm::draw\n");)
    twins[0].draw_ball(pRenderer);
    twins[1].draw_ball(pRenderer);
}
bool mlm::is_out_of_boarder(int x,int y)
{
    DEBUG(just_for_debug("mlm::is_out_of_boarder\n");)
    return mass_heart.x<-20||mass_heart.y<-20||mass_heart.x>x+20||mass_heart.y>y+20;

}

#include "factory.h"
factory* factory::pFactory=nullptr;
factory::factory(){}
factory::~factory(){}
factory* factory::initial_factory()
{
    if(pFactory==nullptr)
        pFactory=new factory;
    return pFactory;
}
ball* factory::get_ball()
{
    ball *b=new ball;
    return b;
}
player* factory::get_player()
{
    player *p;
    ball *player_ball=get_ball();
    p=p->init_player(player_ball);
    return p;
}
mulan_missle* factory::get_mulan_missle(double x,double y)
{
    mulan_missle *m=new mulan_missle(x,y);
    return m;
}

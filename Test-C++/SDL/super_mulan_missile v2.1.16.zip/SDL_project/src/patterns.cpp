#include <math.h>
#include <iostream>
#include "patterns.h"
using namespace std;
double pi_transform(double v)
{
    return v*3.1415926/180;
}
inline int abs(int num)
{
    if(num<0)
        return -num;
    return num;
}
inline double abs(double num)
{
    if(num<0)
        return -num;
    return num;
}
pos G_v_change_amount(pos big,pos lit,double V)
{
    double range=sqrt(pow(big.x-lit.x,2)+pow(big.y-lit.y,2));
    double strength=G*(range*range)*V;
    double costh=(big.x-lit.x)/range;
    double sinth=(big.y-lit.y)/range;
    pos v_change;
    v_change.x=strength*costh;
    v_change.y=strength*sinth;
    return v_change;
}
pos G_force(const pos obj_1,const int m1,const pos obj_2,const int m2)
{
    int x=abs(obj_1.x-obj_2.x),y=abs(obj_1.y-obj_2.y);
    double dis=sqrt(pow(x,2)+pow(y,2));
    double F=G*m1*m2/(dis*dis);
    pos ret;
    ret.x=F*x/dis;
    ret.y=F*y/dis;
    return ret;
}
//vec class fuctions
double vec::length()
{
    return sqrt(x*x+y*y);
}
double dot(vec a,vec b)
{
    return a.x*b.x+a.y*b.y;
}
double cos(vec a,vec b)
{
    return dot(a,b)/(a.length()*b.length());
}
vec vec::operator+(vec val)
{
    val.x+=x;
    val.y+=y;
    return val;
}
void vec::operator+=(const vec val)
{
    x+=(val.x);
    y+=(val.y);
}
//pos fuctions
void pos::change_pos_by_V(double dx,double dy)
{
    x+=dx;
    y+=dy;
}
//mlm fuctions
void mlm_single_twin_update(const pos &mass_heart,vec &mass_heart_vec,pos &twins,const double routine,double V,const int num)
{
    vec dp;
    double cosx=cos(routine)*((num==0)? 1:-1),
           k=sqrt(1.0+(1/(cosx*cosx))),
           cosa=1.0/cosx/k,      sina=1.0/k,
           cost=mass_heart_vec.x,sint=mass_heart_vec.y;
    dp.x=V*k*cosx*(cosa*cost-sina*sint);
    dp.y=V*k*cosx*(sina*cost+sint*cosa);
    twins.change_pos_by_V(dp.x,dp.y);
}
void mlm_move(pos &mass_heart,vec &mass_heart_vec,pos *twins,unsigned int &routine,unsigned int dR,double V)
{
    //mass heart update
    double cur=pi_transform(routine);
    mass_heart.x+=mass_heart_vec.x*V;
    mass_heart.y+=mass_heart_vec.y*V;
    routine+=(dR);
    routine%=360;
    mlm_single_twin_update(mass_heart,mass_heart_vec,twins[0],cur,V,0);
    mlm_single_twin_update(mass_heart,mass_heart_vec,twins[1],cur,V,1);
}


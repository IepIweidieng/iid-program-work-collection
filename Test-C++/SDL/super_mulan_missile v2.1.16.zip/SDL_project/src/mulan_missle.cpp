#include "mulan_missle.h"
#include <math.h>
#include <iostream>
#include "patterns.h"
#if MLDEBUG==1
#define DEBUG(str) str
#define just_for_debug(str) std::cout<<str
#else
#define DEBUG(str) ;
#endif

typedef mulan_missle mlm;
unsigned int mlm::mis_amount=0;
const double mlm::dR=10.0;
mulan_missle::mulan_missle(double _x, double _y):    /*the start point*/
  mass_heart (_x, _y), routine (5.5),
  twins (new pos[2]) , object (new ball[2])
{
    DEBUG(just_for_debug("mulan_missle::mulan_missle\n");)

    twins[0].x=twins[1].x=_x;
    twins[0].y=twins[1].y=_y;

    object[0].change_rad(object[0].get_rad()*0.5);
    object[1].change_rad(object[1].get_rad()*0.5);
    object[0].change_pos(_x, _y);
    object[1].change_pos(_x, _y);
    object[0].change_color();
    object[1].change_color();
    mis_amount++;
    DEBUG(just_for_debug("exit\n");)
}

mulan_missle::mulan_missle(){mis_amount++;}

mulan_missle::mulan_missle(mulan_missle const &_val):
  mass_heart (_val.mass_heart), routine (_val.routine),
  twins (new pos[2])          , object (new ball[2]),
  mass_heart_vec (_val.mass_heart_vec)

{
    DEBUG(just_for_debug("mulan_missle::mulan_missle (copy)\n");)
    routine=_val.routine;
    mass_heart.x = _val.mass_heart.x;
    mass_heart.y = _val.mass_heart.y;
    mass_heart_vec.x =_val.mass_heart_vec.x;
    mass_heart_vec.y =_val.mass_heart_vec.y;
    object[0] = _val.object[0];
    object[1] = _val.object[1];
    twins[0] =_val.twins[0];
    twins[1] =_val.twins[1];
    ++mis_amount;
}

mulan_missle &mulan_missle::operator=(mulan_missle const &_val)
{
    DEBUG(just_for_debug("mulan_missle::mulan_missle (assign)\n");)
    routine=_val.routine;
    mass_heart.x = _val.mass_heart.x;
    mass_heart.y = _val.mass_heart.y;
    mass_heart_vec.x =_val.mass_heart_vec.x;
    mass_heart_vec.y =_val.mass_heart_vec.y;
    object[0] = _val.object[0];
    object[1] = _val.object[1];
    twins[0] =_val.twins[0];
    twins[1] =_val.twins[1];
    return *this;
}
mulan_missle::~mulan_missle()
{
    DEBUG(just_for_debug("mulan_missle::~mulan_missle\n");)
    delete [] twins;
    delete [] object;
    mis_amount--;
}
void mulan_missle::missle_initialize(double p_x/*the way where it goes.*/,
                                     double p_y)
{
    DEBUG(just_for_debug("mulan_missle::missle_initialize\n");)
    //initialize all the velocity of missile
    mass_heart_vec.x=p_x-mass_heart.x;
    mass_heart_vec.y=p_y-mass_heart.y;
    double R=mass_heart_vec.length();
    mass_heart_vec.x/=R;
    mass_heart_vec.y/=R;
}
void mlm::draw(SDL_Renderer* pRenderer)
{
    DEBUG(just_for_debug("mlm::draw\n");)
    object[0].draw_ball(pRenderer);
    object[1].draw_ball(pRenderer);
}
bool mlm::is_out_of_boarder(int _x, int _y)
{
    DEBUG(just_for_debug("mlm::is_out_of_boarder\n");)
    return mass_heart.x < -20 || mass_heart.y < -20 ||
             mass_heart.x > _x+20 || mass_heart.y > _y+20;
}
void mlm::move(double V)
{
    DEBUG(just_for_debug("mlm::move\n");)
    mlm_move(mass_heart,mass_heart_vec,twins,routine,dR,V);
    object[0].change_pos(twins[0].x,twins[0].y);
    object[1].change_pos(twins[1].x,twins[1].y);
}

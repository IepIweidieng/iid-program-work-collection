#include <iostream>
#include <bitset>
#include <string>
using namespace std;
class sflt{ public:
  bool RfltN,
       R
  void* Rflt,
        R
  sflt(){
    void* Rint
  }
  operator bitset<>{

  }
};
bitset<n> add (bitset<n> &x, bitset<n> &y){
  bitset<n> s (x^y),
            c ((x&y)<<1);
  while (c.any()){
    s^=c, c=((~s)&c)<<1;
  }
  return s^=c, s;
}
int _(int n){return n;}
int main(){
  return _(1)+
         _(2)+
         _(3)+
         _(4);
}

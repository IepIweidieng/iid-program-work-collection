//2016.9.27 by Iep Iweidieng.
#include <iostream>
#include <algorithm>
#include <queue>

using namespace std;

struct family{
  vector<family*> near;
  size_t lines(){return this->near.size();}
  friend inline void link(family &lhs, family &rhs){
    lhs.near.push_back(&rhs),rhs.near.push_back(&lhs);
  }
};

struct bpsl{
  family* pos;
  size_t step;
  family* bpos;
  bpsl(family*  pos=NULL, size_t step=0,
       family* bpos=NULL               ): pos( pos), step(step),
                                         bpos(bpos)            {}
};
int main(){
  ios_base::sync_with_stdio(false), cin.tie(NULL), cout.unsetf(ios::unitbuf);
  string trash;
  size_t n;

  cin>> n, getline(cin, trash);

  family *mems(new family[n]);
  for (size_t i={0}, a, b; i<n-1; ++i){
    cin>> a>> b, getline(cin, trash), link(mems[a], mems[b]);
  }

  intmax_t *max_d(new intmax_t[n]);
  fill(&max_d[0], &max_d[n], -1);

  queue<bpsl> bps;
  for (size_t i={0}; i<n; ++i) if (mems[i].lines()==1) bps.push(bpsl(&mems[i], 0));

  bpsl cur;{size_t mems_ind, posst_t;
    while (!bps.empty()){
      cur=bps.front(), bps.pop(), posst_t=cur.pos->lines(),
      mems_ind=cur.pos-&mems[0];
      if (cur.step>max_d[mems_ind]){max_d[mems_ind]=cur.step;} else {continue;}
      if (cur.step&& (posst_t==1|| cur.step>n)) continue;
      for (size_t i={0}; i<posst_t; ++i)
        cur.pos->near[i]!=cur.bpos&&
        (bps.push(bpsl(cur.pos->near[i], cur.step+1, cur.pos)), true);
    }
  }
  cout<< cur.step<< endl;

  delete[] mems, delete[] max_d;
  return 0;
}
﻿//2016-10-1. Primary version by Iep Iweidieng.

/*Issue: Can't spawn child process of child processes
           without the debugger.*/

#include <iostream>
#include <string>
#include <cstdlib>
#include <unistd.h>

#define OFF 0
#define CPP 1
#define CPLPL 2
#define CPLPL_NEW 3

#define FASION_MODE OFF

#if FASION_MODE == CPP
  char nuclear[]={
    #define FG FF, FF, FF, FF, FF, FF, FF, FF, FE, FE
    #define FF FE, FE, FE, FE, FE, FE, FE, FE, FE, FE
    #define FE FD, FD, FD, FD, FD, FD, FD, FD, FD, FD
    #define FD FC, FC, FC, FC, FC, FC, FC, FC, FC, FC
    #define FC FB, FB, FB, FB, FB, FB, FB, FB, FB, FB
    #define FB FA, FA, FA, FA, FA, FA, FA, FA, FA, FA
    #define FA F_, F_, F_, F_, F_, F_, F_, F_, F_, F_
    #define F_ -1
    FG
    #undef F_
    #undef FA
    #undef FB
    #undef FC
    #undef FD
    #undef FE
    #undef FF
    #undef FG
  };

#elif FASION_MODE == CPLPL
  size_t const nuclear_sz(1234567890);
  char nuclear[nuclear_sz];

#elif FASION_MODE == CPLPL_NEW
  template<typename Type> struct Type_a{
    size_t size;
    Type *const ptr2arr;
    Type_a(size_t const &sz):size(sz), ptr2arr(new Type[sz]){}
    Type_a(Type_a const &rhs):size(rhs.size), ptr2arr(new Type[rhs.size]){}
    Type_a& operator=(Type_a const &rhs){
      this->size=rhs.size, delete[](this->ptr2arr);
      try{
        new(this->ptr2arr)Type[rhs.size];
      } catch (std::bad_alloc){this->size=0;}
      return *this;
    }
    ~Type_a(){delete[] ptr2arr;}
    Type& operator[](intmax_t &id){return ptr2arr[id];}
  };

  template<typename Type> Type_a<Type> neualloclear(){
    size_t max_nl={0};
    for (size_t i={-(size_t(-1/float(0))+1)}; i>=0; i/=2){
      try{
        if (!i) return Type_a<Type>(max_nl);
        Type_a<Type>(i+max_nl), max_nl+=i;
      } catch (std::bad_alloc){}
    }
    return Type_a<Type>(0);
  }

  Type_a<char> nuclear(neualloclear<char>());

#else
  char nuclear[]={0};

#endif  //FASION_MODE

//sz can't be 0 or get a compiling error.↓↓↓↓↓↓↓↙↙↙↙↙↙↙
/* error: no matching function for call to 'get_size(char [0])'
   note: candidate is:
   note: template<class T, unsigned int sz> size_t get_size(T (&)[sz])
   note:   template argument deduction/substitution failed:            */
template<typename T, size_t sz> inline size_t get_size(T(&)[sz]){return sz;}

#if FASION_MODE == CPLPL_NEW
  //Specialization for Type_a.
  template<typename T> inline size_t get_size(Type_a<T>(&rhs)){return rhs.size;}

#endif // FASION_MODE

namespace para_str {
  using std::string;

//++str
  string& operator++(string&);

//str++
  inline string operator++(string&lhs, int){
    string temp(lhs);
    return ++lhs, temp;
  }
}

namespace{
  using namespace para_str;
  using std::cin;
  using std::cout;
  using std::endl;
}

int main(int argc, char *(argv[])){
  std::ios_base::sync_with_stdio(false),
    cin.tie(NULL),
    cout.unsetf(std::ios::unitbuf);
  string parm(argc>1? argv[argc-1]: "");

  cout<< parm<< " Nuclear: address=="<< &nuclear<<
    ", size=="<< get_size(nuclear)<< '\n';

  _CRTIMP intptr_t (&exe)(int, const char*, const char*, ...)=_spawnl;

  if (++parm=="00"){
    cout<< "Ended normally. Enter enter or return to return."<< endl, cin.get();
  } else {
    cout<< "Exe: address=="<< reinterpret_cast<void*>(exe)<< endl;
    if (exe(_P_WAIT, argv[0], argv[0], parm.c_str(), NULL)){
      cout<< "Ended early. Enter enter or return to return."<< endl, cin.get();
    }
  }
  if (argc==1) cout<< "Enter enter or return to return."<< endl, cin.get();

  return EXIT_SUCCESS;
}

//++str
std::string& para_str::operator++(string&rhs){
  if (rhs.empty()) rhs="/";
  size_t temp={size_t(rhs[0]-'/')};

  rhs[0]='0'+(temp%('{'-'0'));
  for (size_t i={1}; i<=rhs.length()&& temp/('{'-'0'); temp=rhs[i++]-'/'){
    if (i==rhs.length()) rhs.append("/");
    rhs[i]+=temp/('{'-'0');
  }

  return rhs;
}

#undef FASION_MODE
#undef CPLPL_NEW
#undef CPLPL
#undef CPP
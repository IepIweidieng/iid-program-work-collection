#include <iostream>
//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\///
template<class ty> struct array_2d{
    array_2d(size_t _x, size_t _y):
      x (_x), y (_y), p (*new ty[x*y]()){}
    ~array_2d(){delete[] &p; }
 //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//
    ty * operator[](size_t _x){return &(&p)[_x*y]; }
 //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//
    size_t x, y;
    ty & p;
};
//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\///
template<class ty>
 std::istream & operator>>
  (std::istream & lhs, array_2d<ty> & rhs){
    std::string trash;
 {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
    for (size_t i={0}; i<rhs.x; ++i){
        for (size_t j={0}; j<rhs.y; ++j){
            lhs>> rhs[i][j];
        }
     {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
        getline(std::cin, trash);
    }
 {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
    return lhs;
}
//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\///
struct ground{
    friend std::istream & operator>>
      (std::istream & lhs, ground & rhs){
        lhs>> rhs.data, rhs.data=!((rhs.data-'0')/2);
        return lhs;
    }
 //\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//
    unsigned side;
    char data;
};
//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\///
int main(){
    using namespace std;
    ios_base::sync_with_stdio(false),
    cin.tie((ostream *)NULL),
    cout.unsetf(ios::unitbuf);
 {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
    std::string trash;
    unsigned short L, W;
 {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
    while (cin>> L>> W && (L|| W)){
        getline(std::cin, trash);
     {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
        array_2d<ground> place(L, W);
        unsigned max_A;
     {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
        {
            cin>> place;
            for (unsigned i={0}; i<W; ++i){
                if (place[0][i].data){place[0][i].side=1; }
            }
            for (unsigned i={0}; i<L; ++i){
                if (place[i][0].data){place[i][0].side=1; }
            }
            max_A=!place[0][0].data;
        }
     {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
        {
            for (unsigned i={1}; i<L; ++i){
                for (unsigned j={1}; j<W; ++j){
                    if (place[i][j].data){
                        place[i][j].side=
                          min(min(place[i][j-1].side,
                                  place[i-1][j].side),
                              place[i-1][j-1].side)+1;
                        if (place[i][j].side>max_A){
                            max_A=place[i][j].side;
                        }
                    }
                }
            }
        }
     {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
        cout<< max_A*max_A<< '\n';
 //     cout<< flush;
    }
 {{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}{{}}}
    cout<< flush;
    return 0;
}
#include "Calender.h"
int debug_mode(){
  std::cout<< "  -=DEBUG MODE ON=-"<< std::endl;
////replace it with what you want and call it at main()
/**/  ca c1;                                       /**/
/**/  while (c1.input()){                          /**/
/**/  c1.carry();                                  /**/
/**/    c1.show();                                 /**/
/**/    std::cout<< std::endl;                     /**/
/**/  }                        //by Iep Iweidieng  /**/
////replace it with what you want and call it at main()
  return 0;
}